<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5 
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") La #[b ruralidad] más que un territorio, es la expresión de los contextos en donde converge el “campo” con sus prácticas agrícolas, la expresión de la naturaleza, las tradiciones campesinas, la ausencia o baja incidencia de las industrias y las tecnologías arraigadas, la alimentación asociada con lo local, el aislamiento con la urbanización, y sus construcciones, entre otros. 
        .bg-color-1.p-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 En contraste, la ruralidad también está asociada con vías de acceso y de comunicación ausentes o en mal estado; carencia de conectividad, pobreza, bajas oportunidades educativas, médicas y laborales; sobreexplotación de recursos naturales y otros problemas que reflejan tensiones y retos contemporáneos.   
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in") 
                     
    p(data-aos="fade-down") En estas condiciones, la educación y en particular, la educación infantil, ha enfrentado momentos disímiles que han dispuesto a los “Sujetos” educador (maestro, padres, cuidadores, etc.) y educando, frente a realidades que han cambiado históricamente, conforme se van dando nuevos lugares de posicionamiento al discurso del desarrollo, la diversidad, la inclusión social y educativa.
    .row.mb-5.align-items-center 
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/2.png", data-aos="zoom-in")     
      .col-lg-8
        .bg-color-2.p-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 Dentro de la educación rural, se incluyen los momentos que van desde la crianza durante los primeros años de vida, la institucionalidad educativa a través de los colegios y escuelas, las experiencias políticas locales y nacionales y el acceso a los recursos, programas y proyectos emergentes en las agendas priorizadas por los gobiernos en cada década. 
           
        .bloque-texto-c.bg-color-4.p-4
          i.fas.fa-quote-left
          p.mb-2 La crianza en la ruralidad #[b #[em “se ha desarrollado de diferentes maneras, basándose en su cosmovisión de la vida familiar y comunitaria, de los imaginarios que las sociedades rurales tengan en su momento histórico y político, así como de las oportunidades que el medio económico y biofísico les proporcione”]]. 
          span Ávila (2024).

    .bg-color-3.p-4(data-aos="fade-left")
      .row
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/3.svg")
        .col-lg.j1
          p.mb-0 Para avanzar en lo histórico, basta con revisar los principales hitos educativos en distintas décadas, reconociendo, además, como las transformaciones sobre los imaginarios, inciden en prácticas concretas en las realidades rurales.
</template>
