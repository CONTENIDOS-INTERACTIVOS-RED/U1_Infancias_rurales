<template lang="pug">
.curso-main-container.pb-3
  BannerInterno(:subTitulo="'2. ¿Qué es ser niño o niña del campo?'")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.overflow-hidden
    .row.mb-5           
      .col-lg-7.mb-3.mb-lg-0 
        .bg-color-3.p-4.h-100(data-aos="fade-left")
          .row.align-items-start
            .col-lg-auto
              img.img-a.img-t(src="@/assets/curso/temas/23.png")
            .col-lg
              p.mb-0 Dentro de los aspectos positivos de la ruralidad en la infancia, se destacan: la conexión con entornos naturales y los seres vivos, fuentes de agua, alimentos naturales, aire saludable; la cohesión comunitaria entre padres, vecinos, parientes y maestros; la comprensión real de muchos fenómenos naturales como la siembra, la lluvia, las fuentes de agua (mares, ríos, lagunas, entre otros). 
      .col-lg-5
        figure
          img.img-a.img-t(src="@/assets/curso/temas/24.png", data-aos="zoom-in")    

    .row.mb-5.align-items-center 
      .col-lg-4.mb-3.mb-lg-0 
        figure
          img.img-a.img-t(src="@/assets/curso/temas/25.png", data-aos="zoom-in")      
      .col-lg-8
        .bg-color-7.p-4.j1(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 Nacer y crecer en los escenarios rurales, también genera ciertos diferenciales desde el momento del nacimiento, relacionados con las oportunidades de acceso rápido, cercano a sistemas de salud y educativos: la movilidad por zonas dispersas; la dificultad del cuidado de los infantes frente a las arduas tareas del campo asumidas por los adultos; la disponibilidad o escasez de recursos alimenticios, salubres, inocuos y suficientes, entre otros.
        .bg-color-4.p-4.j1(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 Por otro lado, dependiendo de la cultura o grupo étnico, existen #[b factores que inciden de manera positiva o negativa], sobre la crianza y educación de los niños y las niñas.    


    .row.mb-5.align-items-center
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") Dentro de lo positivo está el acercamiento a conocimientos tradicionales y ancestrales y la interconexión con parientes de distintas generaciones; sin embargo, tradiciones asociadas a la violencia de género, la marginalidad de los grupos étnicos, las pautas restrictivas en la crianza y la educación, el trabajo a edad temprana y la responsabilidad de cuidado de menores sobre los adultos mayores o el cuidado de menores sobre sus hermanos menores, son algunas de las condiciones que determinan la brecha de lo rural frente a lo urbano.            

        .bg-color-8.p-4.j1(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 La educación es un derecho fundamental, sin embargo, para algunos niños y niñas rurales este derecho resulta siendo difícil de garantizar, bien sea por el acceso, la cobertura o la calidad.   
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/26.png", data-aos="zoom-in")  
               
    .bg-full-width-3.bg-fondo-1.mb-5
      .px-4.px-md-5.pb-md-3
        .row.justify-content-center.mb-5
          .col-lg-4
            figure
              img.img-a.img-t(src='@/assets/curso/temas/27.png', alt='')              
          .col-lg-8
            SlyderF.text-center(columnas="col-12 col-lg-6")
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/28.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Primero
                p Disponibilidad de maestros y maestras formados y capacitados, para atender la educación en el contexto.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/29.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Segundo
                p Distancias entre la vivienda y las instituciones educativas (dispersión y movilidad).
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/30.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Tercero
                p Conectividad para acceder a recursos educativos, asegurar la permanencia y atender la diversidad.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/31.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Cuarto
                p Medios educativos pertinentes a la edad, el grado y las realidades.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/32.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Quinto
                p Los incentivos y la seguridad para los maestros y directivos docentes.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/33.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Sexto
                p Las condiciones políticas, sociales y culturales asociadas con el conflicto armado, la migración, los desplazamientos, entre otros.
              .bg-color-white.p-4.h-100.sha.brounded-sm
                img(src='@/assets/curso/temas/34.svg' alt='AvatarTop' , style="max-width: 90px").mx-auto.mb-3
                h4.mb-4 Séptimo
                p El trabajo infantil como fenómeno social y económico incide en los índices de deserción escolar.
    #t_2_1.titulo-segundo(data-aos="flip-up")
      h2 #[span 2.1] Las pautas de crianza en el sector rural
    .bg-color-9.mb-5(data-aos="fade-up")
      .row.justify-content-center.align-items-center            
        .col-lg.order-lg-1
          .p-4
            p.mb-0(data-aos="fade-up") En la ruralidad, las actividades diarias asociadas al campo y la composición familiar, inciden sobre la situación económica, la disposición de tiempos para actividades educativas y recreativas, las pautas de crianza y oportunidades de educación para niños y niñas.
        .col-lg-auto.mb-3.mb-lg-0.order-lg-2
          figure
            img.img-a.img-t(src='@/assets/curso/temas/35.png', alt='')                                       
 
    .row.mb-5.align-items-center
      .col-lg-4.mb-3.mb-lg-0
        figure
          img.img-a.img-t(src="@/assets/curso/temas/36.png", data-aos="zoom-in")      
      .col-lg-8
        .bg-color-1.p-4.j1.mb-4(data-aos="fade-left")
          p(data-aos="fade-down").mb-0 Las pautas de crianza en la familia y comunidad, son los procesos, normas y estilos, que se establecen en el sano acompañamiento durante las diferentes etapas de la vida de los niños, desde el nacimiento hasta la adolescencia, aproximadamente. Cada familia o núcleo familiar tiene pautas o modelos propios a partir de las tradiciones, experiencias previas, culturas, saberes locales y condiciones.  
        p(data-aos="fade-down") Dentro de los asuntos particulares y características de la crianza en la ruralidad, se encuentran:     

    .titulo-figura(data-aos="fade-right")
      h5 Tabla 1. 
      span Asuntos particulares y características de la crianza en la ruralidad

    .tabla-a-1.mb-5(data-aos="fade-left") 
      table
        thead.text-center
          tr
            th Situación
            th Factores que inciden
        tbody
          tr
            td.text-bold Socioafectiva
            td La composición familiar, los roles en la crianza, la disponibilidad de tiempos y las tradiciones familiares en la ruralidad, suelen ser diferentes a los de los contextos urbanos. 
          tr
            td.text-bold Construcción de identidad
            td Dadas las estructuras familiares y comunitarias, los niños y las niñas de la ruralidad, tienen como referente de identidad a sus adultos más próximos, dejando de lado la posibilidad de tener múltiples referentes (baja información o difícil acceso a referentes de culturas distintas a las locales).
          tr
            td.text-bold Actividades, roles y entretenimiento
            td Baja disposición para que los niños y niñas rurales, desarrollen actividades recreativas que les permitan socializar y disfrutar, de acuerdo con su etapa de desarrollo. En su lugar, se promueven las tareas diarias asociadas al mantenimiento y cuidado de la vivienda, la atención o cuidado de parientes (adultos mayores o niños más pequeños) y las propias de la labor campesina.
          tr
            td.text-bold Interacción y socialización
            td La crianza suele ser colaborativa y permite la interacción con niños y niñas de edad similar e intergeneracional. Se encuentran agrupaciones familiares que aportan en la crianza (hermanos, primos, vecinos).                                     
          tr
            td.text-bold Recursos educativos y didácticos 
            td La proximidad a espacios culturales, recreativo, educativos o lúdicos, suelen ser escasos o ausentes en la ruralidad. A menos que el escenario mismo “el campo” se convierta en el lugar propicio para la interacción.  

    .bg-full-width.border-top.color-primario
      .p-4.p-md-5
        h2(data-aos="fade-left") MATERIAL COMPLEMENTARIO
        .row.material-complementario
          .col-12.col-md-6.col-lg-7
            p Los invitamos a explorar el material complementario de este curso, en esta sección encontrará recursos que le permitirán profundizar  y enriquecer su aprendizaje en los temas tratados en esta unidad.

            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://www.elespanol.com/enclave-ods/historias/20240910/nino-medio-rural-no-poder-estudiar-realidad-enfrentan-millones-menores/884662059_0.html" target="_blank" rel="noopener noreferrer") EL ESPAÑOL. (2024). Ser niño en el medio rural y no poder estudiar: la realidad a la que se enfrentan más de 98 millones de menores.  
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://www.javeriana.edu.co/recursosdb/5581483/8102914/Informe-79-Educacio%CC%81n-rural-en-Colombia-%28F%29oct.pdf" target="_blank" rel="noopener noreferrer") Pontificia Universidad Javeriana. (2023). Características y retos de la educación rural en Colombia. Informe análisis estadístico LEE 79. 
            p.d-flex.my-4
              img.me-3(src='@/assets/componentes/link.svg' :style="{'max-width':'16px'}")
              a(href="https://www.unicef.org/colombia/situacion-de-la-infancial" target="_blank" rel="noopener noreferrer") UNICEF Colombia. (2023). Situación de la infancia. 

            p.d-flex.my-4
              img.me-3(src='@/assets/template/icono-yt.svg' :style="{'max-width':'16px'}")
              a(href="https://www.youtube.com/watch?v=NCunFE13bTM" target="_blank" rel="noopener noreferrer") Go Escuela. (2023). La educación en zonas rurales.

          .col-12.col-md-6.col-lg-3.offset-lg-1
            figure
              img(src='@/assets/componentes/material-complementario.svg', alt='')

</template>

<script>
export default {
  name: 'Tema2',
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
}
</script>

<style lang="sass"></style>
