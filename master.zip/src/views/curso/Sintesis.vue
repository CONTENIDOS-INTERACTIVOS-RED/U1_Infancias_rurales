<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La unidad 1: Historia de la educación infantil en los contextos rurales, ofrece una mirada profunda sobre las dinámicas sociales, geográficas y políticas que han moldeado la infancia rural en Colombia. A través de un enfoque histórico y contextual, se analizan las condiciones de vida, las prácticas de crianza, las desigualdades estructurales y las oportunidades educativas que enfrentan los niños y las niñas del campo. Esta unidad brinda a los estudiantes una comprensión crítica y humanizada de las infancias rurales, permitiéndoles reconocer sus fortalezas, desafíos y el papel transformador de la educación en estos territorios.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
